package others;


import java.util.Scanner;

public class HibernateTest {
    public static void main(String[] args) {
      
      ManageEmployee m = new ManageEmployee();

      Scanner sc = new Scanner(System.in);
      boolean continueFlag = true;
      
      while(continueFlag)
      {
        System.out.println("ENTER CHOICE:");
        System.out.println("| 0 for Display Current Record |");
        System.out.println("| 1 for Adding New Record |");
        System.out.println("| 2 for UPdating Records |");
        System.out.println("| 3 for Fetching All Records|");
        int choice = sc.nextInt();
      
        switch(choice)
        {
            case 0:
            {
                System.out.println("Give employee id to display");
                int id = sc.nextInt();
                m.getEmployee(id);
                break;
            }
            case 1:
            {
                System.out.println("Give employee details to add [First Name, Last Name, Salary]");
                String emp = sc.next();
                String[] empDetails = emp.split(",");
                Integer empID = m.addEmployee(empDetails[0], empDetails[1], Integer.parseInt(empDetails[2]));
                break;
            }
            case 2:
            {
                System.out.println("Give employee id and salary to update [ID,Salary]");
                String emp = sc.next();
                String[] empDetails = emp.split(",");
                m.updateEmployee(Integer.parseInt(empDetails[0]), Integer.parseInt(empDetails[1]));
                break;
            }
            case 3:
            {
                System.out.println("Give employee id to delete record");
                int id = sc.nextInt();
                m.deleteEmployee(id);
                break;
            }
            case 4:
            {
                m.listEmployees();
                break;
            }
            default:
                System.out.println("Please provide appropriate choice");
        }
        
        System.out.println("Do you want to continue (y/n) : ");
        String ch = sc.next();
        if(ch.equalsIgnoreCase("n"))
            continueFlag = false;
      }
      
      
      m.closeSessionFactory();
   }
}
