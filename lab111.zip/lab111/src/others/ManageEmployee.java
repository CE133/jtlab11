package others;


import others.Employee;
import others.HibernateUtil;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class ManageEmployee {
    
   private static SessionFactory factory = HibernateUtil.getSessionFactory(); 
       
   public Integer addEmployee(String fname, String lname, int salary){
      Session session = factory.openSession();
      Transaction tx = null;
      Integer employeeID = null;
      
      try {
         tx = session.beginTransaction();
         Employee employee = new Employee(fname, lname, salary);
         employeeID = (Integer) session.save(employee); 
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) 
             tx.rollback();
         System.out.println("Error from addEmployee() : "+e); 
      } finally {
         session.close(); 
      }
      return employeeID;
   }
   
   public void listEmployees( ){
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         List employees = session.createQuery("FROM Employee").list(); 
         System.out.println("\nDisplaying all Employees");
         for (Iterator iterator = employees.iterator(); iterator.hasNext();){
            Employee employee = (Employee) iterator.next(); 
            System.out.println(employee); 
         }
         System.out.print("\n");
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) 
             tx.rollback();
         System.out.println("Error from listEmployees() : "+e);  
      } finally {
         session.close(); 
      }
   }
   
   public void getEmployee(Integer employeeID){
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         Employee employee = (Employee)session.get(Employee.class, employeeID); 
         System.out.println(employee);
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) 
             tx.rollback();
         System.out.println("Error from updateEmployee() : "+e); 
      } finally {
         session.close(); 
      }
   }
   
   public void updateEmployee(Integer employeeID, int salary ){
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         Employee employee = (Employee)session.get(Employee.class, employeeID); 
         employee.setSalary( salary );
		 session.update(employee); 
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) 
             tx.rollback();
         System.out.println("Error from updateEmployee() : "+e); 
      } finally {
         session.close(); 
      }
   }
   
   public void deleteEmployee(Integer employeeID){
      Session session = factory.openSession();
      Transaction tx = null;
      
      try {
         tx = session.beginTransaction();
         Employee employee = (Employee)session.get(Employee.class, employeeID); 
         session.delete(employee); 
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) 
             tx.rollback();
         System.out.println("Error from deleteEmployee() : "+e); 
      } finally {
         session.close(); 
      }
   }
   
   public void closeSessionFactory()
   {
       HibernateUtil.closeSessionFactory();
   }
}
